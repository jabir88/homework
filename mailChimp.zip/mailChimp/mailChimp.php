<?php
if (!defined('ABSPATH')) {
    exit;
}

$oxitype = sanitize_text_field($_GET['oxitype']);
$oxiimpport = '';
if(!empty($_GET['oxiimpport'])){
    $oxiimpport = sanitize_text_field($_GET['oxiimpport']);
}

oxi_addons_user_capabilities();
OxiDataAdminImport($oxitype);
global $wpdb;
$table_name = $wpdb->prefix . 'oxi_div_style';
$table_import = $wpdb->prefix . 'oxi_div_import';
$importstyle = $wpdb->get_results("SELECT * FROM $table_import WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
$freeimport =array('style-1');
if (count($importstyle) < 1) {
    foreach ($freeimport as $value) {
        $wpdb->query($wpdb->prepare("INSERT INTO {$table_import} (type, name) VALUES (%s, %s )", array($oxitype, $value)));
    }
    $js = 'location.reload();';
    wp_add_inline_script('oxi-addons-vendor', $js);
}
  $file = array(
                    'Style 1 OXIIMPORTmailChimpOXIIMPORTstyle-1OXIIMPORToxi-addons-preview-BG |rgba(15, 84, 136, 1)|||oxi-mailchimp-text-align ||||||||||oxi-mailchimp-bg-image|rgba(0, 132, 227, 0)|||oxi-mailchimp-full-padding-top |5|5|5|oxi-mailchimp-full-padding-bottom |5|5|5|oxi-mailchimp-full-padding-left |5|5|5|oxi-mailchimp-full-padding-right |5|5|5|oxi-mailchimp-orm-font-size|16|15|14|oxi-mailchimp-color |#a8a8a8|oxi-mailchimp-writing-color |#121212|oxi-mailchimp-font-family |Open+Sans|500|oxi-mailchimp-font-style |normal:1.3|left:0()0()0()rgba(255, 255, 255, 0):|||||oxi-mailchimp-border-color |#f0f0f0|oxi-mailchimp-border-H-color |#081d73|oxi-mailchimp-form-padding-top |10|10|10|oxi-mailchimp-form-padding-bottom |10|10|10|oxi-mailchimp-form-padding-left |10|10|10|oxi-mailchimp-form-padding-right |10|10|10|oxi-mailchimp-form-margin-top |10|10|0|oxi-mailchimp-form-margin-bottom |10|10|0|oxi-mailchimp-form-margin-left |10|10|0|oxi-mailchimp-form-margin-right |10|10|0|oxi-mailchimp-button-width|200|200|180|oxi-mailchimp-button-font-size|17|15|14|oxi-mailchimp-button-color |#ffffff| oxi-mailchimp-button-bg-color |rgba(199, 28, 28, 0)|oxi-mailchimp-button-border-width-top |2|2|2|oxi-mailchimp-button-border-width-bottom |2|2|2|oxi-mailchimp-button-border-width-left |2|2|2|oxi-mailchimp-button-border-width-right |2|2|2|oxi-mailchimp-button-border |solid|#ffffff||oxi-mailchimp-button-font-family |Roboto|600|oxi-mailchimp-button-font-style |normal:1.3|center:1.3()()()rgba(0, 0, 0, 0):1|oxi-mailchimp-button-border-radius-top |0|25|25|oxi-mailchimp-button-border-radius-bottom |0|25|25|oxi-mailchimp-button-border-radius-left |0|25|25|oxi-mailchimp-button-border-radius-right |0|25|25|oxi-mailchimp-button-padding-top |10|10|10|oxi-mailchimp-button-padding-bottom |10|10|10|oxi-mailchimp-button-padding-left |10|10|10|oxi-mailchimp-button-padding-right |10|10|10|oxi-mailchimp-button-margin-top |10|0|0|oxi-mailchimp-button-margin-bottom |10|0|0|oxi-mailchimp-button-margin-left |10|0|0|oxi-mailchimp-button-margin-right |10|0|0|oxi-mailchimp-H-color |#0f5488|oxi-mailchimp-H-bg-color |rgba(255, 255, 255, 1)|oxi-mailchimp-border-hover |solid|#ffffff||oxi-mailchimp-H-border-radius-top |0|25|25|oxi-mailchimp-H-border-radius-bottom |0|25|25|oxi-mailchimp-H-border-radius-left |0|25|25|oxi-mailchimp-H-border-radius-right |0|25|25|oxi-mailchimp-animation||:false:false:500:10:0.2|//|oxi-mailchimp-alert-font-size|17|17|17|oxi-mailchimp-alert-color |#ffffff|oxi-mailchimp-alert-bg-color |rgba(255, 255, 255, 0)|oxi-mailchimp-alert-border-width-top |2|2|2|oxi-mailchimp-alert-border-width-bottom |2|2|2|oxi-mailchimp-alert-border-width-left |2|2|2|oxi-mailchimp-alert-border-width-right |2|2|2|oxi-mailchimp-alert-border |solid|#ffffff||oxi-mailchimp-alert-font-family |Roboto|500|oxi-mailchimp-alert-font-style |normal:1.3|center:0()0()0()rgba(255, 255, 255, 0):|oxi-mailchimp-alert-border-radius-top |50|50|50|oxi-mailchimp-alert-border-radius-bottom |50|50|50|oxi-mailchimp-alert-border-radius-left |50|50|50|oxi-mailchimp-alert-border-radius-right |50|50|50|oxi-mailchimp-alert-padding-top |9|9|9|oxi-mailchimp-alert-padding-bottom |9|9|9|oxi-mailchimp-alert-padding-left |9|9|9|oxi-mailchimp-alert-padding-right |9|9|9|oxi-mailchimp-alert-margin-top |9|9|9|oxi-mailchimp-alert-margin-bottom |9|9|9|oxi-mailchimp-alert-margin-left |9|9|9|oxi-mailchimp-alert-margin-right |9|9|9|oxi-mailchimp-border |1|solid||oxi-mailchimp-form-bR-top |0|0|0|oxi-mailchimp-form-bR-bottom |0|0|0|oxi-mailchimp-form-bR-left |0|0|0|oxi-mailchimp-form-bR-right |0|0|0|||#||oxi-mailchimp-button-text ||#||Subscribe||#||||#|| ||#||oxi-API-key ||#||||#||oxi-list-id ||#||||#||oxi-addons-mailchimp-loading-icon-class ||#||fas fa-spinner fa-spin oxi-icons||#||oxi-addons-mailchimp-loading-text ||#||Please Wait..||#||oxi-addons-mailchimp-alert-text-success ||#||You have Subscribed Successfully!||#||oxi-addons-mailchimp-alert-text-error ||#||You\'re Already Subscribed!||#||oxi-mailchimp-place-holder-text ||#||Email Address||#||',
                    'Style 2 OXIIMPORTmailChimpOXIIMPORTstyle-2OXIIMPORToxi-addons-preview-BG |rgba(61, 79, 179, 1)|||oxi-mailchimp-text-align ||||||||||oxi-mailchimp-bg-image||||oxi-mailchimp-full-padding-top |5|5|5|oxi-mailchimp-full-padding-bottom |5|5|5|oxi-mailchimp-full-padding-left |5|5|5|oxi-mailchimp-full-padding-right |5|5|5|oxi-mailchimp-orm-font-size|16|14|13|oxi-mailchimp-color |#a8a8a8|oxi-mailchimp-writing-color |#121212|oxi-mailchimp-font-family |Open+Sans|500|oxi-mailchimp-font-style |normal:1.3|left:0()0()0()rgba(255, 255, 255, 0):|||||oxi-mailchimp-border-color |#f0f0f0|oxi-mailchimp-border-H-color |#8500eb|oxi-mailchimp-form-padding-top |12|10|9|oxi-mailchimp-form-padding-bottom |12|10|9|oxi-mailchimp-form-padding-left |12|10|9|oxi-mailchimp-form-padding-right |12|10|9|oxi-mailchimp-form-margin-top |10|10|10|oxi-mailchimp-form-margin-bottom |10|10|10|oxi-mailchimp-form-margin-left |7|10|7|oxi-mailchimp-form-margin-right |7|10|7|oxi-mailchimp-button-width|200|200|180|oxi-mailchimp-button-font-size|17|15|14|oxi-mailchimp-button-color |#ffffff| oxi-mailchimp-button-bg-color |rgba(199,28,28,0.00)|oxi-mailchimp-button-border-width-top |2|2|2|oxi-mailchimp-button-border-width-bottom |2|2|2|oxi-mailchimp-button-border-width-left |2|2|2|oxi-mailchimp-button-border-width-right |2|2|2|oxi-mailchimp-button-border |solid|#ffffff||oxi-mailchimp-button-font-family |Roboto|600|oxi-mailchimp-button-font-style |normal:1.3|center:1.3()()()rgba(0, 0, 0, 0):1|oxi-mailchimp-button-border-radius-top |0|25|25|oxi-mailchimp-button-border-radius-bottom |0|25|25|oxi-mailchimp-button-border-radius-left |0|25|25|oxi-mailchimp-button-border-radius-right |0|25|25|oxi-mailchimp-button-padding-top |10|10|10|oxi-mailchimp-button-padding-bottom |10|10|10|oxi-mailchimp-button-padding-left |10|10|10|oxi-mailchimp-button-padding-right |10|10|10|oxi-mailchimp-button-margin-top |10|10|-3|oxi-mailchimp-button-margin-bottom |10|10|-3|oxi-mailchimp-button-margin-left |10|10|-3|oxi-mailchimp-button-margin-right |10|10|-3|oxi-mailchimp-H-color |#8500eb|oxi-mailchimp-H-bg-color |rgba(255,255,255,1.00)|oxi-mailchimp-border-hover |solid|#ffffff||oxi-mailchimp-H-border-radius-top |0|25|25|oxi-mailchimp-H-border-radius-bottom |0|25|25|oxi-mailchimp-H-border-radius-left |0|25|25|oxi-mailchimp-H-border-radius-right |0|25|25|oxi-mailchimp-animation||:false:false:500:10:0.2|//|oxi-mailchimp-alert-font-size|17|17|17|oxi-mailchimp-alert-color |#ffffff|oxi-mailchimp-alert-bg-color |rgba(255,255,255,0.00)|oxi-mailchimp-alert-border-width-top |2|2|2|oxi-mailchimp-alert-border-width-bottom |2|2|2|oxi-mailchimp-alert-border-width-left |2|2|2|oxi-mailchimp-alert-border-width-right |2|2|2|oxi-mailchimp-alert-border |solid|#ffffff||oxi-mailchimp-alert-font-family |Roboto|500|oxi-mailchimp-alert-font-style |normal:1.3|center:0()0()0()rgba(255, 255, 255, 0):|oxi-mailchimp-alert-border-radius-top |50|50|50|oxi-mailchimp-alert-border-radius-bottom |50|50|50|oxi-mailchimp-alert-border-radius-left |50|50|50|oxi-mailchimp-alert-border-radius-right |50|50|50|oxi-mailchimp-alert-padding-top |9|9|9|oxi-mailchimp-alert-padding-bottom |9|9|9|oxi-mailchimp-alert-padding-left |9|9|9|oxi-mailchimp-alert-padding-right |9|9|9|oxi-mailchimp-alert-margin-top |9|9|9|oxi-mailchimp-alert-margin-bottom |9|9|9|oxi-mailchimp-alert-margin-left |9|9|9|oxi-mailchimp-alert-margin-right |9|9|9|oxi-mailchimp-border |1|solid||oxi-mailchimp-form-bR-top |0|0|0|oxi-mailchimp-form-bR-bottom |0|0|0|oxi-mailchimp-form-bR-left |0|0|0|oxi-mailchimp-form-bR-right |0|0|0|||#||oxi-mailchimp-button-text ||#||Subscribe||#||||#|| ||#||oxi-API-key ||#||||#||oxi-list-id ||#||||#||oxi-addons-mailchimp-loading-icon-class ||#||fas fa-spinner fa-spin oxi-icons||#||oxi-addons-mailchimp-loading-text ||#||Please Wait..||#||oxi-addons-mailchimp-alert-text-success ||#||You have Subscribed Successfully!||#||oxi-addons-mailchimp-alert-text-error ||#||You\'re Already Subscribed!||#||oxi-mailchimp-place-holder-email ||#||Email Address||#||oxi-mailchimp-place-holder-fname ||#||First Name||#||oxi-mailchimp-place-holder-lname ||#||Last Name||#||',
                    'Style 3 OXIIMPORTmailChimpOXIIMPORTstyle-3OXIIMPORToxi-addons-preview-BG |rgba(204, 41, 139, 1)|||oxi-mailchimp-text-align |left|||||||||oxi-mailchimp-bg-image||||oxi-mailchimp-full-padding-top |5|5|5|oxi-mailchimp-full-padding-bottom |5|5|5|oxi-mailchimp-full-padding-left |5|5|5|oxi-mailchimp-full-padding-right |5|5|5|oxi-mailchimp-orm-font-size|16|14|13|oxi-mailchimp-color |#a8a8a8|oxi-mailchimp-writing-color |#121212|oxi-mailchimp-font-family |Open+Sans|500|oxi-mailchimp-font-style |normal:1.3|left:0()0()0()rgba(255, 255, 255, 0):|||||oxi-mailchimp-border-color |#f0f0f0|oxi-mailchimp-border-H-color |#8500eb|oxi-mailchimp-form-padding-top |12|8|8|oxi-mailchimp-form-padding-bottom |12|8|8|oxi-mailchimp-form-padding-left |12|8|8|oxi-mailchimp-form-padding-right |12|8|8|oxi-mailchimp-form-margin-top |10|5|10|oxi-mailchimp-form-margin-bottom |10|5|10|oxi-mailchimp-form-margin-left |7|5|7|oxi-mailchimp-form-margin-right |7|5|7|oxi-mailchimp-button-width|200|200|180|oxi-mailchimp-button-font-size|17|15|14|oxi-mailchimp-button-color |#ffffff| oxi-mailchimp-button-bg-color |rgba(199,28,28,0.00)|oxi-mailchimp-button-border-width-top |2|2|2|oxi-mailchimp-button-border-width-bottom |2|2|2|oxi-mailchimp-button-border-width-left |2|2|2|oxi-mailchimp-button-border-width-right |2|2|2|oxi-mailchimp-button-border |solid|#ffffff||oxi-mailchimp-button-font-family |Roboto|600|oxi-mailchimp-button-font-style |normal:1.3|center:1.3()()()rgba(0, 0, 0, 0):1|oxi-mailchimp-button-border-radius-top |0|25|25|oxi-mailchimp-button-border-radius-bottom |0|25|25|oxi-mailchimp-button-border-radius-left |0|25|25|oxi-mailchimp-button-border-radius-right |0|25|25|oxi-mailchimp-button-padding-top |10|10|10|oxi-mailchimp-button-padding-bottom |10|10|10|oxi-mailchimp-button-padding-left |10|10|10|oxi-mailchimp-button-padding-right |10|10|10|oxi-mailchimp-button-margin-top |10|10|10|oxi-mailchimp-button-margin-bottom |10|10|10|oxi-mailchimp-button-margin-left |10|10|10|oxi-mailchimp-button-margin-right |10|10|10|oxi-mailchimp-H-color |#cc298b|oxi-mailchimp-H-bg-color |rgba(255,255,255,1.00)|oxi-mailchimp-border-hover |solid|#ffffff||oxi-mailchimp-H-border-radius-top |0|25|25|oxi-mailchimp-H-border-radius-bottom |0|25|25|oxi-mailchimp-H-border-radius-left |0|25|25|oxi-mailchimp-H-border-radius-right |0|25|25|oxi-mailchimp-animation||:false:false:500:10:0.2|//|oxi-mailchimp-alert-font-size|17|17|17|oxi-mailchimp-alert-color |#ffffff|oxi-mailchimp-alert-bg-color |rgba(255,255,255,0.00)|oxi-mailchimp-alert-border-width-top |2|2|2|oxi-mailchimp-alert-border-width-bottom |2|2|2|oxi-mailchimp-alert-border-width-left |2|2|2|oxi-mailchimp-alert-border-width-right |2|2|2|oxi-mailchimp-alert-border |solid|#ffffff||oxi-mailchimp-alert-font-family |Roboto|500|oxi-mailchimp-alert-font-style |normal:1.3|center:0()0()0()rgba(255, 255, 255, 0):|oxi-mailchimp-alert-border-radius-top |0|0|0|oxi-mailchimp-alert-border-radius-bottom |0|0|0|oxi-mailchimp-alert-border-radius-left |0|0|0|oxi-mailchimp-alert-border-radius-right |0|0|0|oxi-mailchimp-alert-padding-top |9|9|9|oxi-mailchimp-alert-padding-bottom |9|9|9|oxi-mailchimp-alert-padding-left |9|9|9|oxi-mailchimp-alert-padding-right |9|9|9|oxi-mailchimp-alert-margin-top |9|9|9|oxi-mailchimp-alert-margin-bottom |9|9|9|oxi-mailchimp-alert-margin-left |9|9|9|oxi-mailchimp-alert-margin-right |9|9|9|oxi-mailchimp-border |1|solid||oxi-mailchimp-form-bR-top |0|0|0|oxi-mailchimp-form-bR-bottom |0|0|0|oxi-mailchimp-form-bR-left |0|0|0|oxi-mailchimp-form-bR-right |0|0|0|oxi-mailchimp-title-color |#ffffff|oxi-mailchimp-title-font-size|15|15|14|oxi-mailchimp-title-font-family |Open+Sans|500|oxi-mailchimp-title-font-style |normal:1.3|left:0()0()0()#ffffff:|oxi-mailchimp-title-padding-top |8|6|8|oxi-mailchimp-title-padding-bottom |8|6|8|oxi-mailchimp-title-padding-left |0|0|0|oxi-mailchimp-title-padding-right |0|0|0|||#||oxi-mailchimp-button-text ||#||Subscribe||#||||#|| ||#||oxi-API-key ||#||||#||oxi-list-id ||#||||#||oxi-addons-mailchimp-loading-icon-class ||#||fas fa-spinner fa-spin oxi-icons||#||oxi-addons-mailchimp-loading-text ||#||Please Wait..||#||oxi-addons-mailchimp-alert-text-success ||#||You have Subscribed Successfully!||#||oxi-addons-mailchimp-alert-text-error ||#||You\'re Already Subscribed!||#||oxi-mailchimp-place-holder-email ||#||Email Address||#||oxi-mailchimp-place-holder-fname ||#||First Name||#||oxi-mailchimp-place-holder-lname ||#||Last Name||#||oxi-mailchimp-title-email-text ||#||Email Address||#||oxi-mailchimp-title-fname-text ||#||First Name||#||oxi-mailchimp-title-lname-text ||#||Last Name||#||',
                    'Style 4 OXIIMPORTmailChimpOXIIMPORTstyle-4OXIIMPORToxi-addons-preview-BG |rgba(2, 204, 174, 1)|||||||||||||oxi-mailchimp-bg-image||||oxi-mailchimp-full-padding-top |5|5|5|oxi-mailchimp-full-padding-bottom |5|5|5|oxi-mailchimp-full-padding-left |5|5|5|oxi-mailchimp-full-padding-right |5|5|5|oxi-mailchimp-orm-font-size|16|14|13|oxi-mailchimp-color |#a8a8a8|oxi-mailchimp-writing-color |#121212|oxi-mailchimp-font-family |Open+Sans|500|oxi-mailchimp-font-style |normal:1.3|left:0()0()0()rgba(255, 255, 255, 0):|||||oxi-mailchimp-border-color |#f0f0f0|oxi-mailchimp-border-H-color |#8500eb|oxi-mailchimp-form-padding-top |12|8|8|oxi-mailchimp-form-padding-bottom |12|8|8|oxi-mailchimp-form-padding-left |12|8|8|oxi-mailchimp-form-padding-right |12|8|8|oxi-mailchimp-form-margin-top |10|10|10|oxi-mailchimp-form-margin-bottom |10|10|10|oxi-mailchimp-form-margin-left |7|7|7|oxi-mailchimp-form-margin-right |7|7|7|||||oxi-mailchimp-button-font-size|17|15|14|oxi-mailchimp-button-color |#ffffff| oxi-mailchimp-button-bg-color |rgba(46, 46, 46, 1)|oxi-mailchimp-button-border-width-top |2|2|2|oxi-mailchimp-button-border-width-bottom |2|2|2|oxi-mailchimp-button-border-width-left |2|2|2|oxi-mailchimp-button-border-width-right |2|2|2|oxi-mailchimp-button-border |solid|#2e2e2e||oxi-mailchimp-button-font-family |Roboto|600|oxi-mailchimp-button-font-style |normal:1.3|center:1.3()()()rgba(0, 0, 0, 0):1|oxi-mailchimp-button-border-radius-top |0|0|0|oxi-mailchimp-button-border-radius-bottom |0|0|0|oxi-mailchimp-button-border-radius-left |0|0|0|oxi-mailchimp-button-border-radius-right |0|0|0|oxi-mailchimp-button-padding-top |10|10|10|oxi-mailchimp-button-padding-bottom |10|10|10|oxi-mailchimp-button-padding-left |10|10|10|oxi-mailchimp-button-padding-right |10|10|10|oxi-mailchimp-button-margin-top |13|13|13|oxi-mailchimp-button-margin-bottom |13|13|13|oxi-mailchimp-button-margin-left |7|7|7|oxi-mailchimp-button-margin-right |7|7|7|oxi-mailchimp-H-color |#ffffff|oxi-mailchimp-H-bg-color |rgba(189, 39, 189, 1)|oxi-mailchimp-border-hover |solid|#bd27bd||oxi-mailchimp-H-border-radius-top |0|0|0|oxi-mailchimp-H-border-radius-bottom |0|0|0|oxi-mailchimp-H-border-radius-left |0|0|0|oxi-mailchimp-H-border-radius-right |0|0|0|oxi-mailchimp-animation||:false:false:500:10:0.2|//|oxi-mailchimp-alert-font-size|17|17|17|oxi-mailchimp-alert-color |#ffffff|oxi-mailchimp-alert-bg-color |rgba(255, 255, 255, 0)|oxi-mailchimp-alert-border-width-top |2|2|2|oxi-mailchimp-alert-border-width-bottom |2|2|2|oxi-mailchimp-alert-border-width-left |2|2|2|oxi-mailchimp-alert-border-width-right |2|2|2|oxi-mailchimp-alert-border |solid|#ffffff||oxi-mailchimp-alert-font-family |Roboto|500|oxi-mailchimp-alert-font-style |normal:1.3|center:0()0()0()rgba(255, 255, 255, 0):|oxi-mailchimp-alert-border-radius-top |0|0|0|oxi-mailchimp-alert-border-radius-bottom |0|0|0|oxi-mailchimp-alert-border-radius-left |0|0|0|oxi-mailchimp-alert-border-radius-right |0|0|0|oxi-mailchimp-alert-padding-top |9|9|9|oxi-mailchimp-alert-padding-bottom |9|9|9|oxi-mailchimp-alert-padding-left |9|9|9|oxi-mailchimp-alert-padding-right |9|9|9|oxi-mailchimp-alert-margin-top |9|9|9|oxi-mailchimp-alert-margin-bottom |9|9|9|oxi-mailchimp-alert-margin-left |9|9|9|oxi-mailchimp-alert-margin-right |9|9|9|oxi-mailchimp-border |1|solid||oxi-mailchimp-form-bR-top |0|0|0|oxi-mailchimp-form-bR-bottom |0|0|0|oxi-mailchimp-form-bR-left |0|0|0|oxi-mailchimp-form-bR-right |0|0|0|oxi-mailchimp-title-color |#ffffff|oxi-mailchimp-title-font-size|15|15|14|oxi-mailchimp-title-font-family |Open+Sans|500|oxi-mailchimp-title-font-style |normal:1.3|left:0()0()0()#ffffff:|oxi-mailchimp-title-padding-top |8|6|8|oxi-mailchimp-title-padding-bottom |8|6|8|oxi-mailchimp-title-padding-left |0|0|0|oxi-mailchimp-title-padding-right |0|0|0|||#||oxi-mailchimp-button-text ||#||Subscribe||#||||#|| ||#||oxi-API-key ||#||||#||oxi-list-id ||#||||#||oxi-addons-mailchimp-loading-icon-class ||#||fas fa-spinner fa-spin oxi-icons||#||oxi-addons-mailchimp-loading-text ||#||Please Wait..||#||oxi-addons-mailchimp-alert-text-success ||#||You have Subscribed Successfully!||#||oxi-addons-mailchimp-alert-text-error ||#||You\'re Already Subscribed!||#||oxi-mailchimp-place-holder-email ||#||Email Address||#||oxi-mailchimp-place-holder-fname ||#||First Name||#||oxi-mailchimp-place-holder-lname ||#||Last Name||#||oxi-mailchimp-title-email-text ||#||Email Address||#||oxi-mailchimp-title-fname-text ||#||First Name||#||oxi-mailchimp-title-lname-text ||#||Last Name||#||',
                    'Style 5 OXIIMPORTmailChimpOXIIMPORTstyle-5OXIIMPORToxi-addons-preview-BG |rgba(2, 204, 174, 1)|||||||||||||oxi-mailchimp-bg-image|rgba(237, 69, 69, 1)|||oxi-mailchimp-full-padding-top |24|24|24|oxi-mailchimp-full-padding-bottom |24|24|24|oxi-mailchimp-full-padding-left |24|24|24|oxi-mailchimp-full-padding-right |24|24|24|oxi-mailchimp-orm-font-size|16|14|13|oxi-mailchimp-color |#a8a8a8|oxi-mailchimp-writing-color |#121212|oxi-mailchimp-font-family |Open+Sans|700|oxi-mailchimp-font-style |normal:1.3|left:0()0()0()rgba(255, 255, 255, 0):|||||oxi-mailchimp-border-color |#f0f0f0|oxi-mailchimp-border-H-color |#8500eb|oxi-mailchimp-form-padding-top |12|8|8|oxi-mailchimp-form-padding-bottom |12|8|8|oxi-mailchimp-form-padding-left |12|8|8|oxi-mailchimp-form-padding-right |12|8|8|oxi-mailchimp-form-margin-top |10|5|10|oxi-mailchimp-form-margin-bottom |10|5|10|oxi-mailchimp-form-margin-left |7|5|7|oxi-mailchimp-form-margin-right |7|5|7|||||oxi-mailchimp-button-font-size|17|15|14|oxi-mailchimp-button-color |#ffffff| oxi-mailchimp-button-bg-color |rgba(46, 46, 46, 1)|oxi-mailchimp-button-border-width-top |2|2|2|oxi-mailchimp-button-border-width-bottom |2|2|2|oxi-mailchimp-button-border-width-left |2|2|2|oxi-mailchimp-button-border-width-right |2|2|2|oxi-mailchimp-button-border |solid|#2e2e2e||oxi-mailchimp-button-font-family |Roboto|600|oxi-mailchimp-button-font-style |normal:1.3|center:1.3()()()rgba(0, 0, 0, 0):1|oxi-mailchimp-button-border-radius-top |0|0|0|oxi-mailchimp-button-border-radius-bottom |0|0|0|oxi-mailchimp-button-border-radius-left |0|0|0|oxi-mailchimp-button-border-radius-right |0|0|0|oxi-mailchimp-button-padding-top |10|10|10|oxi-mailchimp-button-padding-bottom |10|10|10|oxi-mailchimp-button-padding-left |10|10|10|oxi-mailchimp-button-padding-right |10|10|10|oxi-mailchimp-button-margin-top |15|15|15|oxi-mailchimp-button-margin-bottom |15|15|15|oxi-mailchimp-button-margin-left |7|7|7|oxi-mailchimp-button-margin-right |7|7|7|oxi-mailchimp-H-color |#ed4545|oxi-mailchimp-H-bg-color |rgba(255, 255, 255, 1)|oxi-mailchimp-border-hover |solid|#ffffff||oxi-mailchimp-H-border-radius-top |0|0|0|oxi-mailchimp-H-border-radius-bottom |0|0|0|oxi-mailchimp-H-border-radius-left |0|0|0|oxi-mailchimp-H-border-radius-right |0|0|0|oxi-mailchimp-animation||:false:false:500:10:0.2|//|oxi-mailchimp-alert-font-size|17|17|17|oxi-mailchimp-alert-color |#ffffff|oxi-mailchimp-alert-bg-color |rgba(255, 255, 255, 0)|oxi-mailchimp-alert-border-width-top |2|2|2|oxi-mailchimp-alert-border-width-bottom |2|2|2|oxi-mailchimp-alert-border-width-left |2|2|2|oxi-mailchimp-alert-border-width-right |2|2|2|oxi-mailchimp-alert-border |solid|#ffffff||oxi-mailchimp-alert-font-family |Roboto|500|oxi-mailchimp-alert-font-style |normal:1.3|center:0()0()0()rgba(255, 255, 255, 0):|oxi-mailchimp-alert-border-radius-top |0|0|0|oxi-mailchimp-alert-border-radius-bottom |0|0|0|oxi-mailchimp-alert-border-radius-left |0|0|0|oxi-mailchimp-alert-border-radius-right |0|0|0|oxi-mailchimp-alert-padding-top |9|9|9|oxi-mailchimp-alert-padding-bottom |9|9|9|oxi-mailchimp-alert-padding-left |9|9|9|oxi-mailchimp-alert-padding-right |9|9|9|oxi-mailchimp-alert-margin-top |9|9|9|oxi-mailchimp-alert-margin-bottom |9|9|9|oxi-mailchimp-alert-margin-left |9|9|9|oxi-mailchimp-alert-margin-right |9|9|9|oxi-mailchimp-border |1|solid||oxi-mailchimp-form-bR-top |0|0|0|oxi-mailchimp-form-bR-bottom |0|0|0|oxi-mailchimp-form-bR-left |0|0|0|oxi-mailchimp-form-bR-right |0|0|0|oxi-mailchimp-title-color |#ffffff|oxi-mailchimp-title-font-size|15|15|14|oxi-mailchimp-title-font-family |Open+Sans|500|oxi-mailchimp-title-font-style |normal:1.3|left:0()0()0()#ffffff:|oxi-mailchimp-title-padding-top |8|6|8|oxi-mailchimp-title-padding-bottom |8|6|8|oxi-mailchimp-title-padding-left |0|0|0|oxi-mailchimp-title-padding-right |0|0|0|oxi-mailchimp-max-width|500|500|500|||#||oxi-mailchimp-button-text ||#||Subscribe||#||||#|| ||#||oxi-API-key ||#||||#||oxi-list-id ||#||||#||oxi-addons-mailchimp-loading-icon-class ||#||fas fa-spinner fa-spin oxi-icons||#||oxi-addons-mailchimp-loading-text ||#||Please Wait..||#||oxi-addons-mailchimp-alert-text-success ||#||You have Subscribed Successfully!||#||oxi-addons-mailchimp-alert-text-error ||#||You\'re Already Subscribed!||#||oxi-mailchimp-place-holder-email ||#||Email Address||#||oxi-mailchimp-place-holder-fname ||#||First Name||#||oxi-mailchimp-place-holder-lname ||#||Last Name||#||oxi-mailchimp-title-email-text ||#||Email Address||#||oxi-mailchimp-title-fname-text ||#||First Name||#||oxi-mailchimp-title-lname-text ||#||Last Name||#||',
                );
if ($oxiimpport == 'import') {
    ?>
    <div class="wrap">
        <?php
        echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes');
        echo '<div class="oxi-addons-wrapper">
                <div class="oxi-addons-row">
                    <div class="oxi-addons-view-more-demo" style=" padding-top: 35px; padding-bottom: 35px; ">
                        <div class="oxi-addons-view-more-demo-data" >
                            <div class="oxi-addons-view-more-demo-icon">
                                <i class="fas fa-bullhorn oxi-icons"></i>
                            </div>
                            <div class="oxi-addons-view-more-demo-text">
                                <div class="oxi-addons-view-more-demo-heading">
                                    More Layouts
                                </div>
                                <div class="oxi-addons-view-more-demo-content">
                                    Thank you for using Shortcode Addons. As limitation of viewing Layouts or Design we added some layouts. Kindly check more  <a target="_blank" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >' . oxi_addons_shortcode_name_converter($oxitype) . '</a> design from Oxilab.org. Copy <strong>export</strong> code and <strong>import</strong> it, get your preferable layouts.
                                </div>
                            </div>
                            <div class="oxi-addons-view-more-demo-button">
                                <a target="_blank" class="oxi-addons-more-layouts" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $oxitype) . '" >View layouts</a>
                            </div>
                        </div>
                    </div>
                </div>
           </div>';
        ?>

        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue != 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo '  <div class="oxi-addons-style-preview-bottom-right">
                                    <form method="post" style=" display: inline-block; ">
                                        ' . wp_nonce_field("oxi-addons-$expludedata[1]-style-active-nonce") . '
                                        <input type="hidden" name="oxiactivestyle" value="' . $expludedata[2] . '">
                                        <button class="btn btn-success" title="Active"  type="submit" value="Active" name="addonsstyleactive">Import Style</button>  
                                    </form> 
                                </div>';
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
            </div>
        </div>
    </div>

    <?php
} else {
    $data = $wpdb->get_results("SELECT * FROM $table_name WHERE type = '$oxitype' ORDER BY id DESC", ARRAY_A);
    ?>
    <div class="wrap">
        <?php echo OxiAddonsAdmAdminMenu($oxitype, '', '', 'yes'); ?>
        <?php echo OxiAddonsAdmAdminShortcodeTable($data, $oxitype); ?>
        <div class="oxi-addons-wrapper">
            <div class="oxi-addons-row">
                <?php
                foreach ($file as $value) {
                    $expludedata = explode('OXIIMPORT', $value);
                    $datatrue = '';
                    foreach ($importstyle as $vals) {
                        if ($vals['name'] == $expludedata[2]) {
                            $datatrue = 'true';
                        }
                    }
                    if ($datatrue == 'true') {
                        $number = rand();
                        echo '<div class="oxi-addons-col-1" id="'.$expludedata[2].'"><div class="oxi-addons-style-preview"><div class="oxi-addons-style-preview-top oxi-addons-center">';
                        echo OxiDataAdminShortcode($oxitype, $value);
                        echo '</div>
                         <div class="oxi-addons-style-preview-bottom">
                            <div class="oxi-addons-style-preview-bottom-left">';
                        echo OxiDataAdminShortcodeName($value);
                        echo '       </div>';
                        echo OxiDataAdminShortcodeControl($number, $value, $freeimport);
                        echo '            </div>
                   </div>
                </div>';
                    }
                }
                ?>
                <div class="oxi-addons-col-1 oxi-import">
                    <div class="oxi-addons-style-preview">
                        <div class="oxilab-admin-style-preview-top">
                            <a href="<?php echo admin_url("admin.php?page=oxi-addons&oxitype=$oxitype&oxiimpport=import"); ?>">
                                <div class="oxilab-admin-add-new-item">
                                    <span>
                                        <i class="fas fa-plus-circle oxi-icons"></i>  
                                        Add More Templates
                                    </span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php
    $css = '#style-1 .oxi-addons-style-preview-top{background-color: #0f5488;} '
            . '#style-2 .oxi-addons-style-preview-top{background-color: #8500eb;}'
            . '#style-3 .oxi-addons-style-preview-top{background-color: #cc298b;}'
            . '#style-4 .oxi-addons-style-preview-top{background-color: #02CCAE;}'
            . '';
    echo OxiAddonsInlineCSSData($css);
    echo OxiDataAdminShortcodeModal($oxitype);
}